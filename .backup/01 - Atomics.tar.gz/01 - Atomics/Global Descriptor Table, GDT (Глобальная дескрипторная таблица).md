#computer_architecture 

> Описания сегментов, доступные <u>любой</u> задаче
