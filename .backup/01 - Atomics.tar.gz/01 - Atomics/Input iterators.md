#prog_lang #prog_lang/cpp #prog_lang/cpp/iterators

- Итераторы **только для чтения** данных
- Поддерживают операции `++it, *it`
