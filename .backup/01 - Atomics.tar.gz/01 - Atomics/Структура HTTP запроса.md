#network #network/protocol 

![[Структура HTTP запроса-1715191493672.jpeg]]

[[URI]]