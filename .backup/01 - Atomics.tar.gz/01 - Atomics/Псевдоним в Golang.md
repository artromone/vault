#prog_lang #prog_lang/golang 

> Способ идентификации одной и той же переменной
