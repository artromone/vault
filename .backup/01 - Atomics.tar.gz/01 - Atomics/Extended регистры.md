#computer_architecture #computer_architecture/assembly 

Например, `eax` представляет собой `ax` плюс дополнительные 16 бит→ **32 бита**

`rax` представляет собой регистр `eax` плюс дополнительные 32 бита → **64 бита**