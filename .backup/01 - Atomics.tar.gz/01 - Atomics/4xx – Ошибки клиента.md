#network 

> 4XX Client Error

**400 – Bad Request**
401 – Unathorized
402 – Payment Required
403 – Forbidden
**404 – Not Found**
405 – Method Not Allowed
406 – Not Acceptable
407 – Proxy Authecation Required
408 – Request Timeout
