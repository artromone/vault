#network #network/header 

> Тип содержимого в body и кодировка

