#prog_lang #prog_lang/golang #prog_lang/golang/array 

Гомогенны – значения всех элементов имеют одинаковый тип

[[Инициализация массивов в Golang]]

[[Сравнение массивов в Golang]]