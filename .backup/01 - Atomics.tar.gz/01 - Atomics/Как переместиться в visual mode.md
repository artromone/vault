#vim #vim/motion

```
o
```
