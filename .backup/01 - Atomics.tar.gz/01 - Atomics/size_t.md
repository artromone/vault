#prog_lang #prog_lang/cpp 

> Максимальный размер адреса системы