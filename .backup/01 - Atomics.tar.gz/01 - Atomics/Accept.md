#network #network/header 

> Типы содержимого (MIME Type), которые клиент может обработать (например, HTML)

