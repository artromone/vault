#vcs #vcs/branching  #vcs/commands 

> Переключение между ветками, как более очевидный вариант `git checkout`

- Создать новую ветку: `git switch -c new-feature`
- Переключиться на предыдущую ветку: `git switch -`
