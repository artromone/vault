#vcs #vcs/repo #vcs/howto 

```c
ssh-keygen -t ed25519 -C "<comment>"

ssh-keygen -t rsa -b 2048 -C "art.rom.one@gmail.com"

cat ~/.ssh/name.pub | clip
```

https://github.com/settings/ssh/new
