#vcs #vcs/commands 

Команда удаляет файл и из рабочей директории, и из [[staging area (индекс)]]

