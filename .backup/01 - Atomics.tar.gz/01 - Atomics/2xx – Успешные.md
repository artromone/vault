#network 

> 2XX Success

**200 – OK**
201 – Created
202 – Accepted
203 – Non-authoriative Information
204 – No content
205 – Reset Content
206 – Partial Content
207 – Multi-Status
208 – Already Reported
226 – IM Used
