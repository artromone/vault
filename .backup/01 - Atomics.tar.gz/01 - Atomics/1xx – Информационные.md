#network 

> 1XX Informational

100 – Continue
101 – Switching Protocols
102 – Processing
