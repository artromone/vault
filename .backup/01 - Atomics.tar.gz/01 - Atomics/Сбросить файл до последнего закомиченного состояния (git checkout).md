#vcs #vcs/howto #vcs/commands 

> `git checkout -- <filename>`
