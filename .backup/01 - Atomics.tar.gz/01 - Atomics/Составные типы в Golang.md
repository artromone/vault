#prog_lang #prog_lang/golang

- [[Массивы в Golang]]
- [[Срезы в Golang]]
- [[Отображения]]
- [[Структуры]]
