#network #network/protocol 

![[Структура HTTP ответа-1715191763044.jpeg]]
