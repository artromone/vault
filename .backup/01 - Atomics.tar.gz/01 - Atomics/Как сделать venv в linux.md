#prog_lang/python #prog_lang 

```bash
python3 -m venv venv
source venv/bin/activate
```

```bash
deactivate
```
