#vcs #vcs/arrangement 

- Добавление или удаление файла
- Переименование файла
- Обновление файла до (мы в этом уверены) хорошего состояния
- Когда вы на какое-то время отходите от работы (чтобы начинать точно с пустым [[staging area (индекс)]])
- Когда вводится сомнительный код

> *Committing should be treated like punctuation. Add it at the end of every sentence, and between every break. Committing should reflect the trail of thought you followed to get to the present code.*

> *How your commits appear in your local repository **has no bearing on** how you ultimately share your code with others.*
