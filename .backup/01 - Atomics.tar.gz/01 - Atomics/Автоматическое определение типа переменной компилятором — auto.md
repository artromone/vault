#prog_lang #prog_lang/cpp 

Тип выводится из **типа инициализатора**.

`auto имя = инициализатор;`

`auto i = 7;`        <- int
`auto q = 2.1;`    <- double
`auto c = '2';`    <- char