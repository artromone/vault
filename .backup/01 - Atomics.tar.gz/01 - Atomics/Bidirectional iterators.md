#prog_lang #prog_lang/cpp #prog_lang/cpp/iterators

- Двунаправленные итераторы
- Помимо возможностей [[Forward iterators]], поддерживают операцию `--it`

