#prog_lang #prog_lang/cpp #prog_lang/cpp/iterators

- Итераторы произвольного доступа с наибольшим функционалом
- Поддерживают `++it, --it, it1<it2, it1+n, it1-it2, it[n]`
