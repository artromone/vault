#prog_lang #prog_lang/java

> JVM (Java Virtual Machine) - это виртуальная машина, которая выполняет байт-код `.class` файлов
