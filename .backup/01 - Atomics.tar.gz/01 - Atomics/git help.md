#vcs #vcs/commands #vcs/howto 

Полная справка: `git help help`

Вывести список всех команд: `git help -a` (их больше **150**)
Вывести гайды от создателей гита: `git help -g`
Список терминов: `git help glossary`

Вывести справку о команде: `git help command`
