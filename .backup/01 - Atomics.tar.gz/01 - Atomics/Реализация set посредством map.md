#prog_lang #prog_lang/golang #prog_lang/golang/map 

```go
set := make(map[string]bool) // Множество строк
```

> Не все значения `map[string]bool` являются просто множествами. Иногда это действительно map со значениями true и false
