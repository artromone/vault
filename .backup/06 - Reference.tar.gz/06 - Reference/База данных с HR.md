#prog_lang 

---

- https://t.me/Salunia_olga – 89110042883 – СТЦ
- https://t.me/hrkrasnova – 89938946308 – Авито
- https://t.me/nikavlkv – ... – Яндекс
- https://t.me/mari_belikova – ... – Яндекс
- https://t.me/kseniia_romanovaaaa – 89315833611 – Ядро
- https://t.me/annapeterneva – ... – Касперский
- https://t.me/ktnvvctr – ... - ...
- 